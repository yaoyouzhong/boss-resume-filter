import React from 'react';
import {shot, onRender} from '../engine.js';

export function BossView({shot:s}) {
  const title = s.id === 'intro' || s.id === 'close';
  return <div className={`composition ${s.tone || ''} ${title ? 'brand-shot' : ''}`}>
    <div className="film-top"><strong>BOSS 简历筛选器</strong><span>{s.id === 'codex' ? 'v2.35 新增 · Codex 本机订阅' : 'v2.35 产品概览'}</span></div>
    <div className="copy"><p className="en">{s.headlineEn}</p><h1>{s.headline}</h1><p className="description">{s.description}</p>
      {title && <div className="flow"><span>岗位要求</span><i></i><span>筛选证据</span><i></i><span>人工判断</span></div>}
    </div>
    {s.image && <div className="screen"><img src={`screens/${s.image}`} alt={s.headline} /></div>}
    {s.secondImage && <div className="screen second"><img src={`screens/${s.secondImage}`} alt="候选人查看与复核完整窗口" /></div>}
    <div className="film-footer"><span>实际程序界面 · 合成演示资料</span><span>{title ? 'Windows / macOS · Windows 独立证书核验助手' : s.caption}</span></div>
  </div>;
}

export const buildBoss = id => tl => {
  const s=shot(id), root=document.querySelector(`[data-shot="${id}"]`);
  const screen=root.querySelector('.screen'), second=root.querySelector('.second');
  // A complete title card must be visible in the first encoded frame.
  if (s.id === 'intro') onRender(id, local => {
    root.style.opacity = String(Math.min(1, Math.max(0, (s.end - s.start - local) / .16)));
  });
  else tl.fromTo(root,{opacity:0},{opacity:1,duration:.24},s.start);
  if (s.id !== 'intro') tl.fromTo(root.querySelector('.copy'),{opacity:0},{opacity:1,duration:.3},s.start+.12);
  if(screen) {
    tl.fromTo(screen,{opacity:0},{opacity:1,duration:.3},s.start+.15);
  }
  if(second) {
    tl.set(second,{opacity:0},0);
    tl.to(screen,{opacity:0,duration:.18},s.start+3);
    tl.fromTo(second,{opacity:0},{opacity:1,duration:.3},s.start+3);
  }
  const lines=root.querySelectorAll('.flow i');
  if (s.id === 'intro') tl.set(lines,{scaleX:1},0);
  else tl.fromTo(lines,{scaleX:0},{scaleX:1,stagger:.4,duration:.5},s.start+.8);
  if(s.id !== 'close') tl.to(root,{opacity:0,duration:.16},s.end-.16);
};
