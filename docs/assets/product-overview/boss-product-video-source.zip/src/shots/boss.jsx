import React from 'react';
import {shot, onRender} from '../engine.js';

export function BossView({shot:s}) {
  const title = s.id === 'intro' || s.id === 'close';
  return <div className={`composition ${s.tone || ''} ${title ? 'brand-shot' : ''}`}>
    <div className="film-top"><strong>BOSS 简历筛选器</strong><span>{s.id === 'codex' ? 'v2.35 新增 · Codex 本机订阅' : 'v2.35 产品概览'}</span></div>
    <div className="copy"><p className="en">{s.headlineEn}</p><h1>{s.headline}</h1><p className="description">{s.description}</p>
      {s.points && <ul>{s.points.map(p=><li key={p}>{p}</li>)}</ul>}
      {title && <div className="flow"><span>岗位要求</span><i></i><span>筛选证据</span><i></i><span>人工判断</span></div>}
    </div>
    {s.image && <div className="screen"><img src={`screens/${s.image}`} /></div>}
    {s.secondImage && <div className="screen second"><img src={`screens/${s.secondImage}`} /></div>}
    <div className="film-footer"><span>实际程序界面 · 合成演示资料</span><span>{title ? 'Windows / macOS · Windows 独立证书核验助手' : s.caption}</span></div>
  </div>;
}

export const buildBoss = id => tl => {
  const s=shot(id), root=document.querySelector(`[data-shot="${id}"]`);
  const screen=root.querySelector('.screen'), second=root.querySelector('.second');
  tl.fromTo(root,{opacity:0},{opacity:1,duration:.24},s.start);
  tl.fromTo(root.querySelector('.copy'),{y:24,opacity:0},{y:0,opacity:1,duration:.45,ease:'power2.out'},s.start+.12);
  tl.fromTo(root.querySelectorAll('li'),{x:18,opacity:0},{x:0,opacity:1,stagger:.32,duration:.25},s.start+.75);
  if(screen) {
    tl.fromTo(screen,{clipPath:'inset(0 0 0 100%)'},{clipPath:'inset(0 0 0 0%)',duration:.42,ease:'power2.out'},s.start+.15);
    const img=screen.querySelector('img');
    tl.fromTo(img,{scale:s.scale || 1,x:s.x || 0,y:s.y || 0},{scale:(s.scale || 1)+.035,x:(s.x || 0)-15,y:s.endY ?? ((s.y || 0)-8),duration:s.end-s.start,ease:'none'},s.start);
  }
  if(second) {
    tl.set(second,{opacity:0},0);
    tl.to(screen,{opacity:0,duration:.18},s.start+3);
    tl.fromTo(second,{opacity:0,x:28},{opacity:1,x:0,duration:.3},s.start+3);
  }
  const lines=root.querySelectorAll('.flow i');
  tl.fromTo(lines,{scaleX:0},{scaleX:1,stagger:.4,duration:.5},s.start+.8);
  if(s.id !== 'close') tl.to(root,{opacity:0,duration:.16},s.end-.16);
};
