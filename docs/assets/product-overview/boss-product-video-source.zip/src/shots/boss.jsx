import React from 'react';
import {shot, onRender} from '../engine.js';

function Screen({file, size, hideVersion = false, second = false, hero = false, label}) {
  const [w, h] = size;
  const scale = Math.min((hero ? 1080 : 1728) / w, (hero ? 660 : 808) / h);
  return <div className={`screen ${second ? 'second' : ''} ${hero ? 'hero-preview' : ''}`}>
    <div className="screen-image" style={{width: w * scale, height: h * scale}}>
      <img src={`screens/${file}`} alt={label} />
      {hideVersion && <div className="version-cover" aria-hidden="true" />}
    </div>
  </div>;
}

function Workflow() {
  return <div className="flow"><span>多渠道简历</span><i></i><span>规则 + AI</span><i></i><span>人工复核</span><i></i><span>联系跟进</span></div>;
}

export function BossView({shot:s}) {
  const title = s.id === 'intro' || s.id === 'close';
  return <div className={`composition ${s.tone || ''} ${title ? 'brand-shot' : ''}`}>
    <div className="film-top"><strong>BOSS 简历筛选器</strong><span>本地招聘工作台</span></div>
    <div className="copy"><p className="en">{s.headlineEn}</p><h1>{s.headline}</h1>
      {s.summary && <p className="intro-summary">{s.summary}</p>}
      <p className="description">{s.description}</p>
      {title && !s.coverImage && <Workflow />}
    </div>
    {s.coverImage && <><div className="cover-backdrop" aria-hidden="true" /><Screen file={s.coverImage} size={s.coverImageSize} hideVersion hero label="完整筛选结果工作台，使用演示资料" /><div className="cover-flow"><Workflow /></div></>}
    {s.image && <Screen file={s.image} size={s.imageSize} hideVersion={s.hideSidebarVersion} label={s.headline} />}
    {s.secondImage && <Screen file={s.secondImage} size={s.secondImageSize} second label="候选人查看与复核完整窗口" />}
    <div className="film-footer"><span>实际程序界面 · 合成演示资料</span><span>{title ? 'Windows / macOS · Windows 独立证书核验助手' : s.caption}</span></div>
  </div>;
}

export const buildBoss = id => tl => {
  const s=shot(id), root=document.querySelector(`[data-shot="${id}"]`);
  const screen=root.querySelector('.screen'), second=root.querySelector('.second');
  // A complete title card must be visible in the first encoded frame.
  if (s.id === 'intro') onRender(id, local => {
    root.style.opacity = String(Math.min(1, Math.max(0, (s.end - s.start - local) / .16)));
  });
  else tl.fromTo(root,{opacity:0},{opacity:1,duration:.24},s.start);
  if (s.id !== 'intro') tl.fromTo(root.querySelector('.copy'),{opacity:0},{opacity:1,duration:.3},s.start+.12);
  if(screen && s.id !== 'intro') {
    tl.fromTo(screen,{opacity:0},{opacity:1,duration:.3},s.start+.15);
  }
  if(second) {
    tl.set(second,{opacity:0},0);
    tl.to(screen,{opacity:0,duration:.18},s.start+3);
    tl.fromTo(second,{opacity:0},{opacity:1,duration:.3},s.start+3);
  }
  // The three connectors are part of the readable workflow, so they remain
  // fully visible with the labels instead of appearing after the text.
  if(s.id !== 'close') tl.to(root,{opacity:0,duration:.16},s.end-.16);
};
