// Map every plan.json shot id to a view and a builder. Builders receive the master timeline.
import {BossView, buildBoss} from './boss.jsx';
import {shots} from '../engine.js';
export const SHOT_VIEWS = Object.fromEntries(shots.map(s=>[s.id,BossView]));
export const SHOT_BUILDERS = Object.fromEntries(shots.map(s=>[s.id,buildBoss(s.id)]));
