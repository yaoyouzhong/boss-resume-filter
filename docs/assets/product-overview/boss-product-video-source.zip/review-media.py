"""Extract review evidence from the encoded movie, not just the HTML render."""
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
plan = json.loads((HERE / 'plan.json').read_text(encoding='utf-8'))
ROOT = (HERE / plan['repo']).resolve()
sys.path.insert(0, str(ROOT))
from subprocess_utils import hidden_subprocess
run = hidden_subprocess(subprocess).run

movie = HERE / 'renders/final-features.mp4'
out = HERE / 'evidence'

def ff(*args):
    run(['ffmpeg', '-v', 'error', '-y', *map(str, args)], check=True)

for index, start in enumerate((0, 28), 1):
    ff('-ss', start, '-i', movie, '-t', 28,
       '-vf', 'fps=2,scale=320:180,tile=8x7', '-frames:v', 1,
       out / f'contact-sheet-{index}.jpg')
for cut in [s['start'] for s in plan['shots'][1:]] + [26]:
    ff('-ss', cut - .4, '-i', movie, '-t', 1,
       '-vf', 'fps=10,scale=256:144,tile=10x1', '-frames:v', 1,
       out / f'cut-{cut:02}.jpg')
for time in (0, 2, 8, 13, 19, 24.5, 28, 32, 38, 45, 50, 54.5):
    ff('-ss', time, '-i', movie, '-frames:v', 1, out / f'encoded-{time:04.1f}.png')
print('Extracted 2 fps whole-film sheets, 10 fps strips for all 10 transitions and 12 full-size encoded frames.')
