# Reproduce

npm ci

Install numpy in a local Python environment. Run python prepare.py --repo <product-checkout> --skill <guizang-product-video-skill-directory>. Then npm run build; python <skill>/scripts/mix_audio.py plan.json; node render.mjs --audio assets/master.wav --output renders/final.mp4. The source retains native Tk screenshots using synthetic demonstration data. Production data and credentials are excluded.
