import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {createReadStream} from 'node:fs';
import {readFile, stat, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {chromium} from 'playwright';
const plan=JSON.parse(await readFile('plan.json','utf8'));
const root = path.resolve(plan.repo, 'docs');
const types={'.html':'text/html; charset=utf-8','.css':'text/css','.png':'image/png','.jpg':'image/jpeg','.mp4':'video/mp4','.svg':'image/svg+xml'};
const server=createServer(async(req,res)=>{
  try {
    const file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
    assert.ok(file.startsWith(root+path.sep));
    const info=await stat(file);
    const headers={'Content-Type':types[path.extname(file)]||'application/octet-stream','Accept-Ranges':'bytes'};
    const range=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range||'');
    if(range) {
      const start=Number(range[1]),end=range[2]?Math.min(Number(range[2]),info.size-1):info.size-1;
      res.writeHead(206,{...headers,'Content-Length':end-start+1,'Content-Range':`bytes ${start}-${end}/${info.size}`});
      createReadStream(file,{start,end}).pipe(res);
    } else {
      res.writeHead(200,{...headers,'Content-Length':info.size});
      createReadStream(file).pipe(res);
    }
  } catch {res.writeHead(404);res.end();}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser;
try {
  browser=await chromium.launch({channel:'chrome',headless:true});
  const reports=[];
  for(const viewport of [{width:1280,height:900},{width:390,height:844}]) {
    const page=await browser.newPage({viewport});
    const errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto(`http://127.0.0.1:${server.address().port}/index.html#demo`);
    await page.evaluate(async()=>{
      const video=document.querySelector('video');
      video.preload='auto';video.load();
      if(video.readyState<1) await new Promise((ok,no)=>{video.onloadedmetadata=ok;video.onerror=()=>no(new Error('video load failed'));});
      await new Promise((ok,no)=>{video.onseeked=ok;video.onerror=no;video.currentTime=6;});
      await video.play();
      await new Promise(r=>video.requestVideoFrameCallback(r));
      video.pause();
      video.scrollIntoView({block:'center',behavior:'instant'});
    });
    const report=await page.evaluate(()=>{
      const v=document.querySelector('video'),r=v.getBoundingClientRect();
      return {width:innerWidth,videoWidth:v.videoWidth,videoHeight:v.videoHeight,duration:v.duration,decodedTime:v.currentTime,fit:getComputedStyle(v).objectFit,frame:{x:r.x,width:r.width,height:r.height},documentWidth:document.documentElement.scrollWidth};
    });
    console.log(JSON.stringify(report));
    assert.deepEqual(errors,[]);assert.equal(report.videoWidth,1920);assert.equal(report.videoHeight,1080);
    assert.equal(report.duration,56);assert.equal(report.fit,'contain');assert.ok(report.decodedTime>=6);
    assert.ok(report.documentWidth<=viewport.width);assert.ok(report.frame.x>=0);assert.ok(report.frame.width<=viewport.width);
    assert.ok(Math.abs(report.frame.width/report.frame.height-16/9)<.01);
    await page.screenshot({path:`evidence/homepage-${viewport.width}.png`});
    reports.push(report);await page.close();
  }
  await writeFile('evidence/homepage.json',JSON.stringify(reports,null,2)+'\n');
  console.log(JSON.stringify(reports));
} finally {await browser?.close();await new Promise(r=>server.close(r));}
