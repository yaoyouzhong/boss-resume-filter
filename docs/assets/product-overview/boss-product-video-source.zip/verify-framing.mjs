// Check the actual rendered geometry for every frame, including transitions.
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {serve} from './server.mjs';
const plan = JSON.parse(await readFile('plan.json', 'utf8'));
const {server, url} = await serve();
let browser;
const errors = [], failures = [], screens = new Map();
try {
  browser = await chromium.launch({channel: process.env.FILM_BROWSER_CHANNEL || 'chrome', headless: true});
  const page = await browser.newPage({viewport: {width: plan.width, height: plan.height}});
  page.on('pageerror', e => errors.push(e.message));
  page.on('response', r => { if (r.status() >= 400) errors.push(`${r.status()} ${r.url()}`); });
  await page.goto(url, {waitUntil: 'networkidle'});
  await page.evaluate(async () => {
    await window.__filmReady;
    await document.fonts.ready;
    await Promise.all([...document.images].map(i => i.decode()));
  });
  for (let frame = 0; frame < plan.duration * plan.fps; frame++) {
    const t = frame / plan.fps;
    const result = await page.evaluate(async time => {
      await window.seek(time);
      const problems = [], images = [];
      const rect = el => {const r = el.getBoundingClientRect(); return {x:r.x,y:r.y,w:r.width,h:r.height,right:r.right,bottom:r.bottom};};
      const inside = (a,b) => a.x >= b.x-.1 && a.y >= b.y-.1 && a.right <= b.right+.1 && a.bottom <= b.bottom+.1;
      const overlap = (a,b) => a.x < b.right && a.right > b.x && a.y < b.bottom && a.bottom > b.y;
      for (const root of document.querySelectorAll('.shot')) {
        const st = getComputedStyle(root);
        if (st.visibility === 'hidden' || Number(st.opacity) < .001) continue;
        const copy = root.querySelector('.copy'), header = rect(copy);
        const desc = root.querySelector('.description');
        if (copy.scrollHeight > copy.clientHeight + 1 && !root.querySelector('.brand-shot')) problems.push(`${root.dataset.shot}: copy overflow`);
        if (!root.querySelector('.brand-shot') && rect(root.querySelector('h1')).x + root.querySelector('h1').scrollWidth > header.right + 1) problems.push('title overflow');
        for (const img of root.querySelectorAll('.screen img')) {
          const r=rect(img), p=rect(img.parentElement), css=getComputedStyle(img);
          if (!inside(r,p) || !inside(r,{x:0,y:0,right:1920,bottom:1080})) problems.push(`${img.src}: out of frame`);
          const ratio=(r.w-2)/(r.h-2), natural=img.naturalWidth/img.naturalHeight;
          if (Math.abs(ratio/natural-1) > .003) problems.push(`${img.src}: distorted`);
          if (css.transform !== 'none' || css.clipPath !== 'none' || getComputedStyle(img.parentElement).clipPath !== 'none') problems.push(`${img.src}: crop or camera transform`);
          if (overlap(r,header) || overlap(r,rect(root.querySelector('.film-footer')))) problems.push(`${img.src}: overlaps copy`);
          images.push({file:img.src.split('/').pop(), natural:[img.naturalWidth,img.naturalHeight], bounds:r});
        }
      }
      if (time === 0 && Number(getComputedStyle(document.querySelector('[data-shot="intro"]')).opacity) < .99) problems.push('blank opening');
      return {problems,images};
    }, t);
    failures.push(...result.problems.map(p=>({frame,time:t,problem:p})));
    result.images.forEach(i=>screens.set(i.file,i));
  }
  await mkdir('evidence', {recursive:true});
  const report={frames:plan.duration*plan.fps, screenshots:[...screens.values()], errors, failures};
  await writeFile('evidence/framing.json', JSON.stringify(report,null,2)+'\n');
  assert.deepEqual(errors, []);
  assert.deepEqual(failures, []);
  assert.equal(screens.size, 9);
  console.log(`Verified ${report.frames} frames and ${screens.size} complete screenshots; no clipping, distortion, camera transforms or copy overlap.`);
} finally {
  await browser?.close();
  await new Promise(resolve=>server.close(resolve));
}
