"""Prepare reproducible film assets and an original instrumental score."""
from pathlib import Path
import json
import shutil
import wave
import numpy as np

HERE = Path(__file__).resolve().parent
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--skill', type=Path, required=True)
args = parser.parse_args()
REPO = args.repo.resolve()
SKILL = args.skill.resolve()
specs = [
    ('intro',0,4,'Evidence before action','招聘处理，回到证据','从岗位要求，到筛选、复核与跟进。',None,'','',0,0),
    ('codex',4,11,'Connect with Codex','接入 Codex\n本机订阅','使用本机 ChatGPT 登录。\n无需 API Key。','03-codex-subscription.png','账号额度与图片能力，以实际测试为准','',-320,-150),
    ('job',11,17,'Start with requirements','先明确岗位要求','解析招聘需求后，核对硬条件、技能和权重。','02-job-config-full.png','规则先行，AI 按需增强','dark',-350,-85),
    ('run',17,23,'Keep control in view','运行中\n操作始终可见','查看日志时，开始、停止与运行状态保留在上方。','04-run-full.png','先连接 Chrome，再启动扫描','',-350,-10),
    ('review',23,30,'Review the evidence','先看依据\n再做人工判断','匹配分、命中证据与风险，集中查看和复核。','05-results.png','评分不替代人工判断','',-360,-40),
    ('import',30,35,'Bring your candidates','不同渠道\n统一处理','猎头、内推和其他渠道简历，批量导入与评估。','13-external-import.png','AI 画像增强和简历评估分别开启','dark',0,0),
    ('education',35,42,'Verify certificates','学历与学位\n分批核验','识别姓名、编号与类型，再由本人扫码和确认。','09-education.png','Windows 另提供独立证书核验助手','',-365,-75),
    ('contact',42,48,'Confirm before contact','联系前，先确认','不确定是否发送成功时，先核实实际结果。','12-contact-workbench.png','维护联系清单与后续跟进','dark',0,0),
    ('stats',48,53,'Learn from feedback','结合反馈\n按岗位复盘','看有效反馈样本，了解推荐成效和需要调整的方向。','06-stats.png','合适率与误推率需结合样本量','',-360,-40),
    ('close',53,56,'BOSS Resume Filter','BOSS 简历筛选器 v2.35','Codex 本机订阅接入，让已有工作流继续发挥作用。',None,'','dark',0,0),
]
source_map = {'codex':'gui_codex_support.py','job':'gui_config_page.py','run':'gui_run_page.py','review':'gui_result_page.py','import':'gui_external_import_dialog.py','education':'gui_education_page.py','contact':'gui_contact_queue.py','stats':'gui_stats_page.py'}
shots=[]
for ident,start,end,en,title,desc,image,caption,tone,x,y in specs:
    shots.append(dict(id=ident,start=start,end=end,type='title' if image is None else 'detail',headlineEn=en,headline=title,description=desc,plainExplanation=desc,
                      descriptionAt=.12,claim=True,releaseStatus='v2.35 release candidate',source=['repo:'+source_map.get(ident,'README.md')],
                      component='src/shots/boss.jsx',image=image,caption=caption,tone=tone,x=x,y=y,
                      actions=[dict(id=ident+'-reveal',at=.3,action='真实界面镜头出现' if image else '标题出现',soundRequired=True)]))
shots[1]['points']=['ChatGPT 登录','选择并保存模型','测试连接与图片能力']
shots[1]['endY']=-365
shots[4]['secondImage']='11-review-workbench.png'
for ident in ('import','contact'):
    next(s for s in shots if s['id']==ident)['scale']=.68
sounds=['resolve','click','toggle','sweep','click','pop','success','click','toggle','ding-dong']
plan=dict(demo=False,product='BOSS 简历筛选器 v2.35 产品概览',style='repo',width=1920,height=1080,fps=30,duration=56,repo=str(REPO),
          scope=dict(versions='current product through v2.35 candidate',platforms=['desktop'],basis='Update existing 56-second overview'),
          audioRequired=True,sfxRequired=True,typography=dict(mode='bilingual',zhFont='Microsoft YaHei UI',enFont='Bahnschrift',zhStyle='sans-serif'),
          audio=dict(ducking=dict(enabled=True),music=dict(file='assets/music.wav',gain=.65),cues=[dict(at=s['start']+.3,actionId=s['id']+'-reveal',file='assets/sfx/'+kind+'.wav',gain=.52,role='sfx',kind=kind) for s,kind in zip(shots,sounds)]),shots=shots)
(HERE/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
(HERE/'BRIEF.md').write_text('# v2.35 产品概览更新\n\n保留既有横版56秒、中文、蓝白产品风格；桌面工作流全貌中突出Codex新增能力。使用真实Tk程序的合成演示截图。候选预览不等于公开发布。声音为代码原创配乐与已署明来源的原创动作音效。\n',encoding='utf-8')
(HERE/'public/screens').mkdir(parents=True,exist_ok=True)
for s in shots:
    for key in ('image','secondImage'):
        if s.get(key):shutil.copy2(REPO/'docs/assets/user-guide'/s[key],HERE/'public/screens'/s[key])
shutil.copy2(HERE/'src/product-film.css',HERE/'src/film.css')
shutil.copytree(SKILL/'assets/audio/sfx',HERE/'assets/sfx',dirs_exist_ok=True)
usage=[dict(shotId=s['id'],featureEntry=source_map.get(s['id'],'README.md'),components=[source_map.get(s['id'],'README.md')],styleEntries=['ui_theme.py','gui_style_setup.py'],stateDriver='docs/assets/user-guide/generate_user_guide_screenshots.py',reuseMode='controlled native Tk screenshot',adapters=['CSS crop and camera motion'],exceptions='Tk cannot run in browser; real screenshots reused under existing video-update authorization.') for s in shots]
(HERE/'evidence/component-usage.json').write_text(json.dumps(usage,ensure_ascii=False,indent=2),encoding='utf-8')

# Original restrained 96-BPM score, with a resolving cadence at the final shot.
sr=48000
duration=56
audio=np.zeros((sr*duration,2),dtype=np.float64)
def note(at,length,midi,amp,pan=0):
    n=min(int(length*sr),len(audio)-int(at*sr))
    t=np.arange(n)/sr
    freq=440*2**((midi-69)/12)
    attack=np.minimum(t/.04,1)
    env=attack*np.exp(-t/(length*.38))*np.minimum((length-t)/.25,1).clip(0,1)
    tone=(np.sin(2*np.pi*freq*t)+.18*np.sin(2*np.pi*freq*2*t)+.06*np.sin(2*np.pi*freq*3*t))*env*amp
    start=int(at*sr)
    audio[start:start+n,0]+=tone*(1-pan*.35)
    audio[start:start+n,1]+=tone*(1+pan*.35)
chords=[(50,57,62),(46,53,58),(48,55,60),(45,52,57)]
for bar,at in enumerate(np.arange(0,53,2.5)):
    chord=chords[bar%4]
    for i,midi in enumerate(chord):note(float(at),3,midi,.035,(i-1)*.4)
    for beat in range(4):note(float(at+beat*.625),.85,chord[beat%3]+12,.047,(-1)**beat*.35)
for i,midi in enumerate((50,57,62,66)):note(53+i*.22,2.8,midi,.045,(i-1.5)*.3)
audio*=np.minimum(np.arange(len(audio))/sr/.8,1)[:,None]
audio*=np.minimum((duration-np.arange(len(audio))/sr)/1.3,1)[:,None]
peak=max(abs(audio.min()),abs(audio.max()))
audio*=.4/max(peak,.4)
with wave.open(str(HERE/'assets/music.wav'),'wb') as stream:
    stream.setnchannels(2);stream.setsampwidth(2);stream.setframerate(sr)
    stream.writeframes((audio.clip(-1,1)*32767).astype('<i2').tobytes())
(HERE/'assets/SOURCE.md').write_text('音乐：prepare.py 代码原创，96 BPM，无采样音源。动作音效：guizang-product-video-skill/assets/audio/sfx，保留SOURCE.txt。界面：当前仓库实际Tk控件与合成演示数据，非真实候选人资料。\n',encoding='utf-8')
renderer=HERE/'render.mjs'
renderer.write_text(renderer.read_text(encoding='utf-8').replace("{stdio: 'inherit'}","{stdio: 'inherit', windowsHide: true}"),encoding='utf-8')
print('Prepared 10 shots, real screenshots and original 56-second score')
